import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsPatternComponent } from './news-pattern.component';

describe('NewsPatternComponent', () => {
  let component: NewsPatternComponent;
  let fixture: ComponentFixture<NewsPatternComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewsPatternComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsPatternComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
