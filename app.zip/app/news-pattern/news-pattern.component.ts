import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-news-pattern',
  templateUrl: './news-pattern.component.html',
  styleUrls: ['./news-pattern.component.css']
})
export class NewsPatternComponent implements OnInit {
  displayNews:any;
  constructor(private http:HttpClient) {}
  ngOnInit() {
  }
  
   searchEngine(nn:any)
   {
    this.http.get("https://newsapi.org/v2/everything?q="+nn+"&sortBy=publishedAt&apiKey=bd7421f6fed94bcb92445cfa6c87a837")
    .subscribe((res:any) =>{ 
      this.displayNews=res["articles"]
            console.log(res["articles"]);
          });
  }

}
