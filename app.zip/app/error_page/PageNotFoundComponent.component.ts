import { Component } from '@angular/core';

@Component({
  selector: 'not-found',
  templateUrl: './PageNotFoundComponent.component.html'

})
export class PageNotFoundComponent {
  title = 'practice-io';
}
