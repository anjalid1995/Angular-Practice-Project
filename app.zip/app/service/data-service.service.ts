import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DataServiceService {


  dev:any={getUserDetails:"http://dummy.restapiexample.com/api/v1/employees"}
  constructor(private http: HttpClient) {

   }
   getUserDetails(){
     return this.http.get(this.dev["getUserDetails"]);
   }
}
