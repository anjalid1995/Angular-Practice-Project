import { Component, OnInit, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy } from '@angular/core';
import { DataServiceService } from '../service/data-service.service';

@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit
// OnChanges,
// DoCheck,
// AfterContentInit,
// AfterContentChecked,
// AfterViewInit,
// AfterViewChecked,
// OnDestroy 
{
  products = [
    {
      name: 'Phone XL',
      price: 799,
      description: 'A large phone with one of the best screens'
    },
    {
      name: 'Phone Mini',
      price: 699,
      description: 'A great phone with one of the best cameras'
    },
    {
      name: 'Phone Standard',
      price: 299,
      description: ''
    }
  ];

  // data:any=100;
  constructor(private dataService:DataServiceService) {
    console.log("Lazy loading...");
  }
  // ngOnChanges() {
  //   debugger;
  //     console.log(`ngOnChanges - data is ${this.data}`);
  // }
  // ngOnInit() {
  //     console.log(`ngOnInit  - data is ${this.data}`);
  // }
  // ngDoCheck() {
  //     console.log("ngDoCheck")
  // }
  // ngAfterContentInit() {
  //     console.log("ngAfterContentInit");
  // }
  // ngAfterContentChecked() {
  //     console.log("ngAfterContentChecked");
  // }
  // ngAfterViewInit() {
  //     console.log("ngAfterViewInit");
  // }
  // ngAfterViewChecked() {
  //     console.log("ngAfterViewChecked");
  // }
  // ngOnDestroy() {
  //     console.log("ngOnDestroy");
  // }
  // fnAddNumber():void{
  //     this.data+=100;
  // }
  // deleteNumber():void{
  //     this.data -=10;
  // }

ngOnInit(){

    // this.dataService.getUserDetails().subscribe((data:any)=>{
    //   console.log(data)
    // },error=>{
    //   console.log('unable to get respones');
    // })
}
                                                                                                                                                                                                                                                                                                                                  
getData(){
  alert("Data request process..... ")
  let results=this.dataService.getUserDetails().toPromise();
  console.log(results);  
  results.then((data)=>{
      console.log("Promise resolved with: " + JSON.stringify(data));
    }).catch((error)=>{
      console.log("Promise rejected with " + JSON.stringify(error));
    });
}

show(data){

  console.log("Data is been Processed");
  
}














}
