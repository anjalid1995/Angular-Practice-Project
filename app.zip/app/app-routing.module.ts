import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartComponentComponent } from './cart-component/cart-component.component';
import { PageNotFoundComponent } from './error_page/PageNotFoundComponent.component';

const routes: Routes = [
  {
    path: 'product-list',
    loadChildren:'../app/product-list/product-list.module#ProductListModule'
    //() => import('../app/product-list/product-list.module').then(mod => mod.ProductListModule)
  },
  {
    path:'',
    component:CartComponentComponent
  },
  { path: '**', component: PageNotFoundComponent }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]

})
export class AppRoutingModule {
 constructor(){
  console.log("AppRoutingModule");
 }

}
