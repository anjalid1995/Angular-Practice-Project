import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TopBarComponent } from './product-list/top-bar.component';
import { DataServiceService } from './service/data-service.service';
import { CartComponentComponent } from './cart-component/cart-component.component';
import { PageNotFoundComponent } from './error_page/PageNotFoundComponent.component';
import{ReactiveFormsModule} from '@angular/forms'

@NgModule({
  declarations: [
    AppComponent,
    TopBarComponent,
    CartComponentComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
   ReactiveFormsModule
    
  ],
  providers: [DataServiceService],
  bootstrap: [AppComponent]
})
export class AppModule {
constructor(){
  console.log("AppModule");
}

 }
