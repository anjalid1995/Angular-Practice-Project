import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewsPatternComponent } from './news-pattern/news-pattern.component';
import { RouterModule,Routes } from '@angular/router'; //route imported
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

//create path of component and name 
const appRoute:Routes = [
  { path: 'news-pattern', 
    component: NewsPatternComponent 
  } 
];
@NgModule({
  declarations: [
    AppComponent,
    NewsPatternComponent //new component declared

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoute), //declaring route class which we have imported
    FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
